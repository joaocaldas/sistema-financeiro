

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Relatório de Cheques</h3>
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('cheques.result')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="conta_id">Conta</label>
                                <select name="conta_id" class="form-control" required>
                                    <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($conta->id); ?>">
                                            <?php echo e($conta->bank); ?> - <?php echo e($conta->account_number); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="data_inicial">Data Inicial</label>
                                <input type="date" name="data_inicial" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="data_final">Data Final</label>
                                <input type="date" name="data_final" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
                        </form>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger mt-3">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\sistema-financeiro\resources\views/relatorios/cheques_form.blade.php ENDPATH**/ ?>