

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Relatório de Cheques</h3>
                    </div>
                    <div class="panel-body">
                        <h4>Relatório de Cheques para <?php echo e($conta->bank); ?> - <?php echo e($conta->account_number); ?></h4>
                        <h4>Período: <?php echo e(\Carbon\Carbon::parse($dataInicial)->format('d-m-Y')); ?> a <?php echo e(\Carbon\Carbon::parse($dataFinal)->format('d-m-Y')); ?></h4>
                        
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data de Emissão</th>
                                    <th>Número do Cheque</th>
                                    <th>Valor</th>
                                    <th>Portador</th>
                                    <th>Descrição</th>
                                    <th>Status</th>
                                    <th>Data de Compensação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cheques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cheque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($cheque->issue_date)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($cheque->cheque_number); ?></td>
                                        <td>R$ <?php echo e(number_format($cheque->value, 2, ',', '.')); ?></td>
                                        <td><?php echo e($cheque->payee); ?></td>
                                        <td><?php echo e($cheque->description); ?></td>
                                        <td><?php echo e(ucfirst($cheque->status)); ?></td>
                                        <td><?php echo e($cheque->compensation_date ? \Carbon\Carbon::parse($cheque->compensation_date)->format('d-m-Y') : 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Nenhum cheque encontrado para o período selecionado.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <a href="<?php echo e(route('cheques.form')); ?>" class="btn btn-secondary mt-3">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\sistema-financeiro\resources\views/relatorios/cheques_resultado.blade.php ENDPATH**/ ?>