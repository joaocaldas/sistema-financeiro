

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Relatório de Fluxo de Caixa</h3>
                    </div>
                    <div class="panel-body">
                        <h4>Saldo Anterior: R$ <?php echo e(number_format($saldoAnterior, 2, ',', '.')); ?></h4>
                        
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Fornecedor</th>
                                    <th>Histórico</th>
                                    <th>Entradas</th>
                                    <th>Saídas</th>
                                    <th>Saldo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $saldoAtual = $saldoAnterior;
                                ?>
                                <?php $__currentLoopData = $cheques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cheque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($cheque->issue_date)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($cheque->payee); ?></td>
                                        <td><?php echo e($cheque->description); ?></td>
                                        <td><?php echo e($cheque->status == 'compensated' ? number_format($cheque->value, 2, ',', '.') : '0,00'); ?></td>
                                        <td><?php echo e($cheque->status == 'to_be_compensated' ? number_format($cheque->value, 2, ',', '.') : '0,00'); ?></td>
                                        <td><?php echo e(number_format($saldoAtual, 2, ',', '.')); ?></td>
                                    </tr>
                                    <?php
                                        $saldoAtual += $cheque->status == 'compensated' ? $cheque->value : -$cheque->value;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3">Totais</td>
                                    <td><?php echo e(number_format($entradas, 2, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($saidas, 2, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($saldoAtual, 2, ',', '.')); ?></td>
                                </tr>
                            </tfoot>
                        </table>

                        <a href="<?php echo e(route('relatorio.form')); ?>" class="btn btn-secondary mt-3">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\sistema-financeiro\resources\views/relatorios/fluxo_caixa.blade.php ENDPATH**/ ?>