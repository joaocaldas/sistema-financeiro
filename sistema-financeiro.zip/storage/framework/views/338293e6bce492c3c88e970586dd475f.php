

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Cheques a Compensar</h3>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data de Emissão</th>
                                    <th>Número do Cheque</th>
                                    <th>Valor</th>
                                    <th>Portador</th>
                                    <th>Descrição</th>
                                    <th>Data de Pré-Datado</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cheques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cheque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($cheque->issue_date)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($cheque->cheque_number); ?></td>
                                        <td>R$ <?php echo e(number_format($cheque->value, 2, ',', '.')); ?></td>
                                        <td><?php echo e($cheque->payee); ?></td>
                                        <td><?php echo e($cheque->description); ?></td>
                                        <td><?php echo e($cheque->postdated_date ? \Carbon\Carbon::parse($cheque->postdated_date)->format('d-m-Y') : 'N/A'); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('cheque.compensar', $cheque->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-success">Compensar</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Nenhum cheque a compensar.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success mt-3">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <a href="<?php echo e(route('cheques.form')); ?>" class="btn btn-secondary mt-3">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\sistema-financeiro\resources\views/relatorios/cheques_compensar.blade.php ENDPATH**/ ?>